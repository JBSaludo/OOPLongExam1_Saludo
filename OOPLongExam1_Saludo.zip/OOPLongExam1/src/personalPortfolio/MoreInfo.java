package personalPortfolio;

public class MoreInfo extends BasicInfo {
	
	//Multilevel inheritance | Child class
	String educKinderElem = "Life Giver Academy (2016)";
	String educJHS = "Pasig Christian Academy (2020)";
	String educSHS = "NU Nazareth School (2022)";
	String educCollege = "National University-Manila";
	String achieve1 = "NU First Honor Dean's Lister";
	String achieve2 = "(First & Second Semester)";
	String number = "+63976-285-5734";
	String email = "saludo@gmail.com";
	
}
