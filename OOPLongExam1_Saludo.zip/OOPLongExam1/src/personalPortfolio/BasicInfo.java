package personalPortfolio;

public class BasicInfo extends Description {
	
	//Multilevel inheritance | Parent class
	String name = "JOHN BENEDICT SALUDO";
	String age = "18";
	String birthdate = "JULY 23, 2004";
	String gender = "MALE";
	String course = "BSIT-MWA";
	String whyIT = "DREAM JOB";

}
