package personalPortfolio;

public class Description {
	
	//Multilevel inheritance | Grandparent class
	String LibSys = "Rent books in an organized fashion \nand it includes a login system";
	String TicTacToe = "A timeless classic game implemented \nin java";
	String BMI = "Efficient tool designed to calculate and \nassess an individual's body mass index";

}
